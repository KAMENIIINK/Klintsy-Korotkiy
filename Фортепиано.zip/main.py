import sys

from PyQt5 import QtCore, QtMultimedia, uic
from PyQt5.QtWidgets import QApplication, QMainWindow

PREFIX_PATH = 'mandolin\mandolin_'
SUFFIX_PATH = '4_very-long_piano_normal.mp3'
MAX_PLAYERS_COUNT = 100
NOTES = {
    'Z': 'A',
    'S': 'As',
    'X': 'B',
    'D': 'C',
    'C': 'Cs',
    'V': 'D',
    'G': 'Ds',
    'B': 'E',
    'H': 'F',
    'N': 'Fs',
    'J': 'G',
    'M': 'Gs'
}


class MyWidget(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('ui.ui', self)
        self.buttonGroup.buttonClicked.connect(self.click_btn)
        for key in NOTES:
            filename = PREFIX_PATH + NOTES[key] + SUFFIX_PATH
            media = QtCore.QUrl.fromLocalFile(filename)
            content = QtMultimedia.QMediaContent(media)
            NOTES[key] = content
        self.players = []

    def click_btn(self, button):
        self.play_key(button.text())

    def KeyPressEvent(self, a0):
        try:
            key = chr(a0.key())
            if key in NOTES:
                self.play_key(key)
        except BaseException:
            pass

    def play_key(self, key):
        self.players.append(QtMultimedia.QMediaPlayer())
        self.players[-1].setMedia(NOTES[key])
        self.players[-1].play()
        if len(self.players) > 2 * MAX_PLAYERS_COUNT:
            del self.players[:MAX_PLAYERS_COUNT]


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = MyWidget()
    ex.show()
    sys.exit(app.exec_())
